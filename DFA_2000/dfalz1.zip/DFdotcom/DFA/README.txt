Thank you for downloading "Digital Filter Analyzer". 
I believe this will help you to design digital filters. 

NOTE : After you unzip "dfalz1.zip", please copy "dfalz1.exe" 
and other "*.vhd" files into a directory. 

NOTE : Please see "Online Help" on my web page if you have 
some problem. How to get there is... 
1) Go to http://www.digitalfilter.com 
2) Go to "Software". 
3) Go to "Digital Filter Analyzer". 

NOTE : Please visit "Bug Information" on my web page 
once in a while. 

---------------------------------------------------
Toshio Iwata
1265 North Capitol Avenue #9 San Jose, CA 95132 USA
http://www.digitalfilter.com
---------------------------------------------------
